﻿namespace TempConv
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button0 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.buttonNeg = new System.Windows.Forms.Button();
            this.buttonDec = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonClear = new System.Windows.Forms.Button();
            this.temp1 = new System.Windows.Forms.Label();
            this.temp2 = new System.Windows.Forms.Label();
            this.temp3 = new System.Windows.Forms.Label();
            this.unit3 = new System.Windows.Forms.Label();
            this.unit1 = new System.Windows.Forms.ComboBox();
            this.unit2 = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button0
            // 
            this.button0.Location = new System.Drawing.Point(288, 234);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(50, 50);
            this.button0.TabIndex = 0;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button_Click);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(232, 66);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 1;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(288, 66);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 50);
            this.button2.TabIndex = 2;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(344, 66);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(50, 50);
            this.button3.TabIndex = 3;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(232, 122);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(50, 50);
            this.button4.TabIndex = 4;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(288, 122);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 50);
            this.button5.TabIndex = 5;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(344, 122);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 50);
            this.button6.TabIndex = 6;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(232, 178);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(50, 50);
            this.button7.TabIndex = 7;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(288, 178);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(50, 50);
            this.button8.TabIndex = 8;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(344, 178);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(50, 50);
            this.button9.TabIndex = 9;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button_Click);
            // 
            // buttonNeg
            // 
            this.buttonNeg.Location = new System.Drawing.Point(232, 234);
            this.buttonNeg.Name = "buttonNeg";
            this.buttonNeg.Size = new System.Drawing.Size(50, 50);
            this.buttonNeg.TabIndex = 10;
            this.buttonNeg.Text = "-/+";
            this.buttonNeg.UseVisualStyleBackColor = true;
            this.buttonNeg.Click += new System.EventHandler(this.button_Click);
            // 
            // buttonDec
            // 
            this.buttonDec.Location = new System.Drawing.Point(344, 234);
            this.buttonDec.Name = "buttonDec";
            this.buttonDec.Size = new System.Drawing.Size(50, 50);
            this.buttonDec.TabIndex = 11;
            this.buttonDec.Text = ".";
            this.buttonDec.UseVisualStyleBackColor = true;
            this.buttonDec.Click += new System.EventHandler(this.button_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Location = new System.Drawing.Point(313, 290);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(81, 50);
            this.buttonBack.TabIndex = 12;
            this.buttonBack.Text = "⌫";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.button_Click);
            // 
            // buttonClear
            // 
            this.buttonClear.Location = new System.Drawing.Point(232, 290);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(75, 50);
            this.buttonClear.TabIndex = 13;
            this.buttonClear.Text = "Clear";
            this.buttonClear.UseVisualStyleBackColor = true;
            this.buttonClear.Click += new System.EventHandler(this.button_Click);
            // 
            // temp1
            // 
            this.temp1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.temp1.AutoSize = true;
            this.temp1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.temp1.Location = new System.Drawing.Point(84, 6);
            this.temp1.Name = "temp1";
            this.temp1.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.temp1.Size = new System.Drawing.Size(13, 19);
            this.temp1.TabIndex = 15;
            this.temp1.Text = "0";
            // 
            // temp2
            // 
            this.temp2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.temp2.AutoSize = true;
            this.temp2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.temp2.Location = new System.Drawing.Point(78, 93);
            this.temp2.Name = "temp2";
            this.temp2.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.temp2.Size = new System.Drawing.Size(19, 19);
            this.temp2.TabIndex = 16;
            this.temp2.Text = "32";
            // 
            // temp3
            // 
            this.temp3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.temp3.AutoSize = true;
            this.temp3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.temp3.Location = new System.Drawing.Point(57, 180);
            this.temp3.Name = "temp3";
            this.temp3.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.temp3.Size = new System.Drawing.Size(40, 19);
            this.temp3.TabIndex = 17;
            this.temp3.Text = "273.15";
            // 
            // unit3
            // 
            this.unit3.AutoSize = true;
            this.unit3.Location = new System.Drawing.Point(103, 180);
            this.unit3.Name = "unit3";
            this.unit3.Padding = new System.Windows.Forms.Padding(0, 6, 0, 0);
            this.unit3.Size = new System.Drawing.Size(14, 19);
            this.unit3.TabIndex = 18;
            this.unit3.Text = "K";
            // 
            // unit1
            // 
            this.unit1.FormattingEnabled = true;
            this.unit1.Items.AddRange(new object[] {
            "C",
            "F",
            "K"});
            this.unit1.Location = new System.Drawing.Point(103, 9);
            this.unit1.Name = "unit1";
            this.unit1.Size = new System.Drawing.Size(32, 21);
            this.unit1.TabIndex = 19;
            this.unit1.Text = "C";
            this.unit1.SelectedIndexChanged += new System.EventHandler(this.update);
            this.unit1.SelectionChangeCommitted += new System.EventHandler(this.update);
            this.unit1.SelectedValueChanged += new System.EventHandler(this.update);
            this.unit1.Click += new System.EventHandler(this.update);
            // 
            // unit2
            // 
            this.unit2.FormattingEnabled = true;
            this.unit2.Items.AddRange(new object[] {
            "C",
            "F",
            "K"});
            this.unit2.Location = new System.Drawing.Point(103, 96);
            this.unit2.Name = "unit2";
            this.unit2.Size = new System.Drawing.Size(32, 21);
            this.unit2.TabIndex = 20;
            this.unit2.Text = "F";
            this.unit2.SelectedIndexChanged += new System.EventHandler(this.update);
            this.unit2.SelectionChangeCommitted += new System.EventHandler(this.update);
            this.unit2.SelectedValueChanged += new System.EventHandler(this.update);
            this.unit2.Click += new System.EventHandler(this.update);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.unit1, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.temp3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.unit3, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.unit2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.temp1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.temp2, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(26, 66);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.Padding = new System.Windows.Forms.Padding(6);
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(200, 274);
            this.tableLayoutPanel1.TabIndex = 21;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 411);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.buttonClear);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonDec);
            this.Controls.Add(this.buttonNeg);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button0);
            this.MaximumSize = new System.Drawing.Size(450, 450);
            this.MinimumSize = new System.Drawing.Size(450, 450);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button buttonNeg;
        private System.Windows.Forms.Button buttonDec;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Label temp1;
        private System.Windows.Forms.Label temp2;
        private System.Windows.Forms.Label temp3;
        private System.Windows.Forms.Label unit3;
        private System.Windows.Forms.ComboBox unit1;
        private System.Windows.Forms.ComboBox unit2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}

