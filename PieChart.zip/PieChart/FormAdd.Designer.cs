﻿namespace PieChart
{
    partial class FormAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private System.Windows.Forms.TextBox textType;
        private System.Windows.Forms.TextBox textAbrv;
        private System.Windows.Forms.TextBox textDesc;
        private System.Windows.Forms.Panel panColor;
        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.TextBox textBox1;
    }
}